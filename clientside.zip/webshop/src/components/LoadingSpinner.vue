<template>
   <div class="text-center">
        <b-spinner type="grow" label="Loading..."></b-spinner>
    </div>
</template>

<script>
    export default { 
    name: "LoadingSpinner"
    }
</script>