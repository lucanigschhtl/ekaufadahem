<template>

<b-container class="d-none d-md-block" fluid>
  <!-- Content here -->

		<b-nav class="fixed-bottom" variant="info">
            <b-nav-item>Datenschutzvereinbarung</b-nav-item>
            <b-nav-item>Kontakt</b-nav-item>
            <b-nav-item>Impressum</b-nav-item>
		</b-nav>
</b-container>	
</template>

<script>
  export default {
    name: 'TheUserFooter'
   
  }
</script>


